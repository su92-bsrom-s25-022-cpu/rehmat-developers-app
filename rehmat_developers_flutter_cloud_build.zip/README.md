# Rehmat Developers Flutter App

## Build APK without installing Flutter on your computer

1. Create a new **public** repository on GitHub, for example `rehmat-developers-app`.
2. Extract this ZIP on your computer using Windows' built-in Extract All option.
3. Open the extracted folder. Upload the contents of the folder (not the outer folder itself) to the repository so that `pubspec.yaml`, `lib/`, and `.github/` are at the repository root.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Enable workflows if GitHub asks.
6. Select **Build Rehmat Developers APK**, then click **Run workflow** if it has not started automatically.
7. Wait for the workflow to finish with a green check.
8. Open the completed workflow run. Under **Artifacts**, download `rehmat-developers-android-apk`.
9. Extract the downloaded artifact ZIP and copy `app-release.apk` to your Android phone.
10. Open the APK on your phone and allow installation from that source if Android asks.

## Important
- GitHub Actions runs the Flutter build in the cloud; Flutter and Android Studio are not required on your computer.
- This workflow uploads the APK as an artifact for 30 days.
- A public repository is required for this setup to use GitHub-hosted standard runners without Actions minute charges.
- This is a test/distribution APK, not a Google Play Store release.
- Keep the repository free of passwords, API keys, private signing keys or customer data.
